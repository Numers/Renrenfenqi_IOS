﻿/**
 * User: Administrator
 * Date: 2015/5/4
 * Time: 13:03
 * Description:TODO
 */
var h5 = h5 || {};

h5.client = function (client) {
    GoodsDetail.getClient(client);
};

h5.pageInit = function (goods) {
    GoodsDetail.getParams(goods);
};

h5.userAssess = function (assess) {
    if (assess) {
        GoodsDetail.setUserAssess(assess);
    }
};
