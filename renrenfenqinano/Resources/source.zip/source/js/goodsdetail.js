/**
 * User: guyunxiang
 * Date: 2015/4/23
 * Time: 17:26
 * Description:TODO
 */

var GoodsDetail = (function () {

    var _utilities = _utilities || {}, paramsObj = paramsObj || {}, dataObj = dataObj || {}, client = client || {}, orderObj = orderObj || {}, _getParams, _setUserAssess, _getClient;

    /**
     * 初始化兼职控件
     * @js_job 1 == 兼职
     */
    _utilities.isJob = function (is_job) {
        if (dataObj.data.is_job == 1) {
            if (is_job == 1) {
                $('.add').css('display', 'block');
                $('.part-time').css('display', 'block').attr('data-sign', '1');
                $('.month-pay-work').css('display', 'block');
                // 初始化兼职可选
                orderObj.prohibit_job = 0;
                // 初始化兼职选中
                orderObj.is_job = 1;
            } else if (is_job == 0) {
                $('.add').css('display', 'none');
                $('.part-time').css('display', 'none').attr('data-sign', '0');
                $('.month-pay-work').css('display', 'none');
                // 初始化兼职未选中
                orderObj.is_job = 0;
            }
        } else {
            $('.add').css('display', 'none');
            $('.part-time').css('display', 'none').attr('data-sign', '0');
            $('.month-pay-work').css('display', 'none');
            // 初始化兼职未选中
            orderObj.is_job = 0;
        }
    };

    /**
     * 设置兼职可选样式
     * @param type 1=取消兼职|0=选择兼职
     */
    _utilities.setJobs = function (type) {
        if (orderObj.prohibit_job == 0) {
            if (type == 1) {
                $('.part-time').css('border', '#cccccc solid 1px').attr('data-sign', '0').find('b').css('color', '#444444');
                $('.part-time img').css('display', 'none');
                $('.add').css('color', '#cccccc');
                orderObj.is_job = 0;
            } else {
                $('.part-time').css('border', '#f44e4e solid 1px').attr('data-sign', '1').find('b').css('color', '#f44e4e');
                $('.part-time img').css('display', 'block');
                $('.add').css('color', '#f44e4e');
                orderObj.is_job = 1;
            }
        }
    };

    // 初始化商品外形参数
    _utilities.setPagePamParams = function () {
        var params = '', swiper;
        // 初始化商品名称
        $('#goods_name').text(dataObj.data.goods_list[0].goods_name);
        // 初始化商品图片下标总和
        $('.all').text(dataObj.data.images.length);
        // 初始化参数页面布局
        $('.goods-params').replaceWith("<ul class='goods-params'></ul>");
        var thimagesLength = dataObj.data.images.length;
        for (var k = 0; k < thimagesLength; k++) {
            var goods_img = "<div class='swiper-slide'><img src='" + dataObj.data.images[k] + "' alt=''/></div>";
            $('.swiper-wrapper').append(goods_img);
        }
        // 商品展示滑动效果
        swiper = new Swiper('.swiper-container', {
            freeMode: false,
            onSlideChangeEnd: function () {
                // 设置商品图片滑动下标的改变
                $('.active').text(swiper.activeIndex + 1);
            }
        });
        // 判断是否有配置参数
        if (!dataObj.data.description) {
            $("#goods_params").hide();
            $("#goods_details").css("border", "0px");
        }
        var attributesLength = dataObj.data.attributes.length;
        for (var i = 0; i < attributesLength; i++) {
            if (dataObj.data.attributes[i].attr_name) {
                $('.goods-params').append("<li class='params-" + i + "'></li>");
                $('.params-' + i).append("<span>" + dataObj.data.attributes[i].attr_name + "：</span>").append("<div class='params-" + i + "'></div>");
                var attrvalueLength = dataObj.data.attributes[i].attr_value.length;
                for (var j = 0; j < attrvalueLength; j++) {
                    var templete = "<p class='params-true' data-name=" + dataObj.data.attributes[i].attr_value[j] + ">" + dataObj.data.attributes[i].attr_value[j] + "<img class='params_img' src='../../img/detail/detail_body_tick2_h@2x.png' alt=''/></p>";
                    $('div.params-' + i).append(templete);
                    // 默认设置第一个参数被选中
                    $("p[data-name='" + dataObj.data.attributes[i].attr_value[0] + "']").addClass('active-btn').css("border", "#f44e4e solid 1px").children().css("display", "block");
                }
            }
        }
        // 遍历被选中的参数
        $('.params-true').each(function () {
            if ($(this).attr('class') == 'params-true active-btn') {
                params += $(this).attr('data-name') + ":";
            }
        });
        dataObj.params = params;
    };

    /**
     * 根据用户选择的商品参数设置商品名称、价格及分期参数
     * @params 商品参数 格式 ==> 16G:金色:开放版:
     * @returns {*}
     */
    _utilities.setgoodsParams = function (params) {
        // 去除字符串最后一个":"
        var param = params.substring(0, params.length - 1), result;
        // 遍历商品查询用户选择当前的商品是否存在
        var goodslistLength = dataObj.data.goods_list.length;
        for (var i = 0; i < goodslistLength; i++) {
            if (dataObj.data.goods_list[i].attr_val_list == param) {
                result = dataObj.data.goods_list[i];
            }
        }
        if (dataObj.data.available == 1 && result) {
            $('.goods-buy-btn').css('background-color', "#f44e4e").text('立即购买');
            $('.window-pay-body-ul').replaceWith("<ul class='window-pay-body-ul'></ul>");
            $('.window-date-body-ul').replaceWith("<ul class='window-date-body-ul'></ul>");
            $('.goods-price .month-pay .month').css('width', '50%');
            // 判断商品信息是否完整
            if (result.goods_name && result.goods_price && result.first_pay && result.period_price) {
                $('#goods_name').text(result.goods_name);
                $('#price').text('￥' + result.goods_price);
                _utilities.setfirstPayLi(result.goods_price, result.first_pay, result.period_price);
            } else {
                _utilities.getError();
                return false;
            }
        } else {
            _utilities.goodsAvailable();
            result = null;
        }
        return result;
    };

    // 处理商品无货的情况
    _utilities.goodsAvailable = function () {
        // 初始化商品名称
        $('#goods_name').text(dataObj.data.goods_map_name);
        // 初始化商品价格
        $('#price').text('暂无售价');
        // 初始化商品首付
        $('#first_pay_span').text("0%首付");
        $('#first-pay').text("");
        // 初始化分期
        $('#date-pay-span').text("0个月");
        $('#month-money').text("￥" + 0);
        // 初始化兼职金额
        $('#jobs').text(0);
        $('#job_times').text(0);
        $('#month-date').text(0);
        $('.goods-buy-btn').css('background-color', "#cccccc").text('暂时无货');
        $('.goods-price .month-pay .month').css('width', '43%');
    };

    // 重置首付和分期显示
    _utilities.setPriceSpanText = function (per, date) {
        if (per == 0) {
            $('#first_pay_span').text(per + "%首付");
        } else {
            $('#first_pay_span').text(per + "%");
        }
        $('#date-pay-span').text(date + "个月");
        $('#month-date').text(date);
        $('#job_times').text(date);
    };

    /**
     * 设置首付和分期选项
     * @goods_price 商品价格
     * @first_pay 首付比例
     * @period_price 分期数
     */
    _utilities.setfirstPayLi = function (goods_price, first_pay, period_price) {
        var credit, $window_pay_body_ul = $(".window-pay-body-ul"), $window_date_body_ul = $(".window-date-body-ul");
        // 信用额度是否足够
        if (dataObj.data.credit) {
            credit = dataObj.data.credit;
            if (Number(credit) < 0) {
                credit = 0;
            }
        } else if (dataObj.data.default_credit) {
            credit = dataObj.data.default_credit;
        } else {
            _utilities.getError();
            return false;
        }
        for (var i = 0; i < first_pay.length; i++) {
            var credit_now = Number(goods_price) - Number(goods_price) * Number(first_pay[i] / 100);
            if (Number(credit) > credit_now) {
                var templete_pay = "<li data-sign='" + first_pay[i] + "' data-name='pay'>" + first_pay[i] + "%</li>";
                $window_pay_body_ul.append(templete_pay);
            } else {
                $("li[data-sign='0']").remove();
            }
        }
        $("li[data-name='pay']").each(function () {
            if ($(this).attr('data-sign')) {
                if ($(this).text() == "0%") {
                    $("#first_pay_span").text($(this).text() + "首付");
                } else {
                    $("#first_pay_span").text($(this).text());
                }
                return false;
            }
        });
        for (var j = 0; j < period_price.length; j++) {
            var templete_period = "<li data-sign='" + period_price[j].period + "' data-name='date'>" + period_price[j].period + "个月</li>";
            $window_date_body_ul.append(templete_period);
        }
        $window_pay_body_ul.append("<li style='height: 50px'></li>");
        $window_date_body_ul.append("<li style='height: 50px'></li>");
    };

    // 显示遮罩层
    _utilities.showMask = function (speed) {
        $('body').css("overflow", "hidden");
        $('.mask').fadeIn(speed);
    };

    // 隐藏遮罩层
    _utilities.hideMask = function (speed) {
        $('body').css("overflow", "visible");
        $('.mask').fadeOut(speed);
    };

    /**
     * 设置计算对应公式参数值
     * @param formula
     */
    _utilities.setFormula = function (formula) {
        if (formula == "1") {
            dataObj.a = 0.09;
            dataObj.b = 0;
            dataObj.c = 0.13;
        } else if (formula == "2") {
            dataObj.a = 0.15;
            dataObj.b = 0;
            dataObj.c = 0.13;
        } else if (formula == "3") {
            dataObj.a = 0.09;
            dataObj.b = 0;
            dataObj.c = 0;
        } else if (formula == "4") {
            dataObj.a = 0.15;
            dataObj.b = 0;
            dataObj.c = 0;
        } else if (formula == "5") {
            dataObj.a = 0;
            dataObj.b = 0;
            dataObj.c = 0.13;
        }
    };

    /**
     * 计算商品价格
     * @param formula 计算公式
     * @param per 首付比例
     * @param times 分期次数
     * @param goods 商品信息
     */
    _utilities.computePrice = function (formula, per, times, goods) {
        var percent = Number(per) / 100, first_pay, rest_price, purchase_price, goods_price, job_price;
        // 使用formula对应公式，0==自定义公式，1-5==对应计算公式
        if (formula == "0") {
            // 100%首付的商品价格
            if (percent == 1) {
                // 市场价 = 商品标价
                goods_price = Number(goods.goods_price);
                // 首付金额 = 市场价
                first_pay = goods_price;
                // 月供 = 0
                orderObj.month_pay = 0;
                $("#first-pay").text("￥" + parseInt(first_pay));
                $("#price").text('￥' + parseInt(goods_price));
            } else {
                // 是否可以兼职，是，获取兼职金额
                if (dataObj.data.is_job == 1) {
                    job_price = Number(dataObj.data.job_price);
                    // 兼职金额
                    orderObj.job_price = job_price;
                    $('#jobs').text((job_price / times).toFixed(2));
                }
                // 查询对应分期的商品价格
                for (var i = 0; i < goods.period_price.length; i++) {
                    if (goods.period_price[i].period == times) {
                        // 市场价 = 商品对应分期的标准金额
                        goods_price = Number(goods.period_price[i].price);
                        $('#price').text('￥' + goods_price);
                    }
                }
                // 0首付的商品价格
                if (percent == 0) {
                    // 如果可以兼职且选择兼职，商品价格 > 兼职金额
                    if (dataObj.data.is_job == 1 && goods_price > job_price) {
                        if (orderObj.is_job == 1) {
                            // 商品价格 = 市场价 - 兼职金额
                            rest_price = goods_price - job_price;
                            // 设置兼职选中
                            _utilities.setJobs(0);
                        } else {
                            rest_price = goods_price;
                        }
                        // 设置兼职可以选择
                        orderObj.prohibit_job = 0;
                    } else {
                        // 剩余价格 = 商品价格
                        rest_price = goods_price;
                        // 设置兼职未选中
                        _utilities.setJobs(1);
                        // 设置兼职无法选择
                        orderObj.prohibit_job = 1;
                    }
                    // 首付金额 = 0
                    first_pay = 0;
                    // 月供 = 商品价格 / 分期数
                    orderObj.month_pay = (rest_price / times).toFixed(2);
                    $("#first-pay").text("");
                } else {// 有首付的商品价格
                    // 首付金额 = 市场价 * 首付比例
                    first_pay = (goods_price * percent).toFixed(2);
                    // 剩余金额 = 商品价格 - 首付金额
                    rest_price = goods_price - first_pay;
                    // 如果可以兼职 ，且 剩余金额 < 兼职金额 ， 则取消兼职
                    if (dataObj.data.is_job == 1 && rest_price > job_price) {
                        if (orderObj.is_job == 1) {
                            // 商品价格 = 剩余价格 - 兼职金额
                            rest_price = rest_price - job_price;
                            _utilities.setJobs(0);
                        }
                        orderObj.prohibit_job = 0;
                    } else {
                        _utilities.setJobs(1);
                        orderObj.prohibit_job = 1;
                    }
                    // 月供 = 商品价格 / 分期数
                    orderObj.month_pay = (rest_price / times).toFixed(2);
                    $("#first-pay").text("￥" + first_pay);
                }
            }
            $("#month-money").text('￥' + orderObj.month_pay);
        } else {
            _utilities.setFormula(formula);
            // 商品进货价
            purchase_price = Number(goods.purchase_price);
            // 判断进货价是否存在
            if (!purchase_price) {
                _utilities.getError();
                return false;
            }
            // 100%首付的商品价格
            if (percent == 1) {
                // 市场价 = 进货价 * （1 + a + b）
                goods_price = purchase_price * (1 + dataObj.a + dataObj.b);
                // 首付金额 = 市场价
                first_pay = goods_price;
                // 月供 = 0
                orderObj.month_pay = 0;
                _utilities.setJobs(1);
                $("#first-pay").text("￥" + parseInt(first_pay));
                $("#price").text('￥' + parseInt(goods_price));
                $('#jobs').text(0);
            } else {
                // 是否兼职，是，获取兼职金额
                if (dataObj.data.is_job == 1) {
                    job_price = Number(dataObj.data.job_price);
                    // 兼职金额
                    orderObj.job_price = job_price;
                    $('#jobs').text((job_price / times).toFixed(2));
                }
                // 0首付的商品价格
                if (percent == 0) {
                    // 市场价 X2 = 进货价 * （1 + a + b）+ 进货价 * （1 + a + b）* （c/12*分期数）
                    var tmp = purchase_price * (1 + dataObj.a + dataObj.b);
                    goods_price = (tmp + tmp * (dataObj.c / 12 * times)).toFixed(2);
                    // 设置页面商品价格
                    $("#price").text('￥' + parseInt(goods_price));
                    // 如果兼职，且 商品价格 < 兼职金额 ， 则取消兼职
                    if (dataObj.data.is_job == 1 && goods_price > Number(dataObj.data.job_price)) {
                        if (orderObj.is_job == 1) {
                            // 商品剩余价格 = 市场价 - 兼职金额
                            rest_price = goods_price - job_price;
                            _utilities.setJobs(0);
                        } else {
                            // 商品剩余价格 = 市场价
                            rest_price = goods_price;
                        }
                        orderObj.prohibit_job = 0;
                    }
                    else {
                        // 商品剩余价格 = 市场价
                        rest_price = goods_price;
                        _utilities.setJobs(1);
                        orderObj.prohibit_job = 1;
                    }
                    // 首付金额
                    first_pay = 0;
                    // 月供 = 商品价格 / 分期数
                    orderObj.month_pay = (rest_price / times).toFixed(2);
                    $("#first-pay").text("");
                } else { // 其他首付的商品金额
                    // 市场价 X3 = 进货价*（1+a+b）+ 进货价*（1-首付比例）*（1+a+b）*(c/12*分期数)
                    goods_price = purchase_price * (1 + dataObj.a + dataObj.b) + purchase_price * (1 - percent) * (1 + dataObj.a + dataObj.b) * (dataObj.c / 12 * times);
                    // 设置页面商品价格
                    $("#price").text('￥' + parseInt(goods_price));
                    // 首付金额 = 市场价 * 首付比例
                    first_pay = (goods_price * percent).toFixed(2);
                    // 剩余价格 = 商品价格 - 首付金额
                    rest_price = goods_price - first_pay;
                    // 如果可以兼职，且 剩余金额 < 兼职金额 ， 则取消兼职
                    if (dataObj.data.is_job == 1 && rest_price > Number(dataObj.data.job_price)) {
                        if (orderObj.is_job == 1) {
                            // 商品价格 = 剩余金额 - 兼职金额
                            rest_price = rest_price - job_price;
                            _utilities.setJobs(0);
                        }
                        orderObj.prohibit_job = 0;
                    } else {
                        _utilities.setJobs(1);
                        orderObj.prohibit_job = 1;
                    }
                    // 月供 = 商品价格 / 分期数
                    orderObj.month_pay = (rest_price / times).toFixed(2);
                    $("#first-pay").text("￥" + first_pay);
                }
            }
            $('#month-money').text('￥' + orderObj.month_pay);
        }
        _utilities.setPriceDateLi(per, times);
        _utilities.setOrderParams(per, times, goods, goods_price, first_pay);
    };

    // 设置首付选单和分期选单的选中状态
    _utilities.setPriceDateLi = function (per, times) {
        $(".window-pay-body-ul").children().css('color', 'black');
        $(".window-date-body-ul").children().css('color', 'black');
        $('.window-pay-body-ul li').each(function () {
            if ($(this).attr('data-sign') == per) {
                $(this).css("color", "#28A4C9");
            }
        });
        $('.window-date-body-ul li').each(function () {
            if ($(this).attr('data-sign') == times) {
                $(this).css("color", "#28A4C9");
            }
        });
    };

    // 设置用户订单信息
    _utilities.setOrderParams = function (per, times, goods, goods_price, first_pay) {
        // 后端接口需要参数
        // 子商品id
        paramsObj.goods_id = goods.goods_id;
        // 首付比例
        paramsObj.first_pay = per;
        if (per == "100") {
            // 分期数
            paramsObj.periods = 1;
        } else {
            // 分期数
            paramsObj.periods = times;
        }
        paramsObj.is_job = orderObj.is_job;

        // 下单页面需要参数
        // 商品名称
        orderObj.goods_map_name = dataObj.data.goods_map_name;
        // 子商品名称
        orderObj.goods_name = goods.goods_name;
        // 商品价格
        orderObj.goods_price = parseInt(goods_price);
        // 首付金额
        orderObj.first_pay = first_pay;
        // 首付比例
        orderObj.first_pay_percent = per;
        // 分期数
        orderObj.period = times;
        // 商品缩略图
        orderObj.goods_img = dataObj.data.images[0];
        // 兼职金额
        if (orderObj.is_job == 0) {
            orderObj.job_price = 0;
        }
    };

    // 获取用户选择的首付和分期参数
    _getParams = function (data) {
        var me = this, self, per = 0, date = 3, goods;
        dataObj = data;
        me.utilities.isJob(dataObj.data.is_job);
        me.utilities.setPagePamParams();
        goods = me.utilities.setgoodsParams(dataObj.params);
        if (goods) {
            me.utilities.computePrice(goods.formula, per, date, goods);
        }
        // 获取用户选择商品参数
        $('.goods-params').on('touchstart', function (e) {
            self = $(e.target);
            if (self.attr('class') == 'params-true') {
                var params = '';
                self.parent().find('.params-true').css({
                    "border": "#cccccc solid 1px"
                });
                self.parent().find('.params-true img').css("display", "none");
                $(e.target).css({
                    "border": "#f44e4e solid 1px"
                });
                self.parent().find('.active-btn').removeClass('active-btn');
                $(e.target).children().css({
                    "display": "block"
                });
                $(e.target).addClass('active-btn');
                $('.params-true').each(function () {
                    if ($(this).attr('class') == 'params-true active-btn') {
                        params += $(this).attr('data-name') + ":";
                    }
                });
                dataObj.params = params;
            }
            // 设置商品参数
            goods = me.utilities.setgoodsParams(dataObj.params);
            if (goods) {
                me.utilities.setPriceSpanText(per, date);
                me.utilities.computePrice(goods.formula, per, date, goods);
            } else {
                me.utilities.goodsAvailable();
            }
        });
        // 获取用户选择首付和分期参数
        $('.goods-price').on('touchstart', function (e) {
            self = $(e.target);
            if (goods) {
                // 用户点击首付和分期
                if (self.attr('data-name') == 'price-btn') {
                    me.utilities.showMask(400);
                    $('.window-date').slideUp();
                    $('.window-pay').slideDown(300);
                } else if (self.attr('data-name') == 'date-btn') {
                    // 如果首付是100%,则不可选择分期数
                    if (per !== '100') {
                        me.utilities.showMask(400);
                        $('.window-pay').slideUp();
                        $('.window-date').slideDown(300);
                    }
                }
                // 用户点击什么是兼职
                if (self.attr('class') == 'month-pay-work') {
                    me.utilities.showMask(0);
                    $('.parttime').show();
                }
                // 用户选择首付和这分期数
                if (self.attr('data-name') == 'pay') {
                    $(".window-pay-body-ul").children().css('color', 'black');
                    per = self.attr('data-sign');
                    // 如果首付金额为100%，则初始化分期数为0
                    if (per == 100) {
                        date = 0;
                    } else {
                        // 如果分期数为0，则初始化分期数为3
                        if (!date) {
                            date = 3;
                        }
                    }
                    self.css("color", "#28A4C9");
                } else if (self.attr('data-name') == 'date') {
                    $(".window-date-body-ul").children().css('color', 'black');
                    date = self.attr('data-sign');
                    self.css("color", "#28A4C9");
                }
                // 用户确认选择首付和分期数
                if (self.attr('data-name') == 'price-ok') {
                    // 如果首付是100%，则隐藏兼职金额
                    if (per == 100) {
                        $('#month-money').text('￥' + date);
                        $('#first_pay_span').text(per + "%");
                        me.utilities.isJob(0);
                    } else if (per == 0) {
                        $('#first_pay_span').text('0%首付');
                        me.utilities.isJob(1);
                    } else {
                        $('#month-money').text('￥' + date);
                        $('#first_pay_span').text(per + "%");
                        me.utilities.isJob(1);
                    }
                    $('.date-pay-btn span').text(date + '个月');
                    $("#month-date").text(date);
                    $('#job_times').text(date);
                    me.utilities.hideMask(400);
                    $('.window-pay').slideUp();
                    $('.window-date').slideUp();
                    me.utilities.computePrice(goods.formula, per, date, goods);
                } else if (self.attr('data-name') == 'price-back') {
                    me.utilities.hideMask(400);
                    $('.window-pay').slideUp();
                    $('.window-date').slideUp();
                }
            }
        });
        // 用户选择兼职
        $('.part-time').on('touchstart', function () {
            me.utilities.setJobs(orderObj.is_job);
            me.utilities.computePrice(goods.formula, per, date, goods);
        });
        // 打开商品详情
        $("#goods_details").on('click', function () {
            if (client == 'android') {
                renrenAct.goGoodsDetail(dataObj.data.description);
            } else {
                window.location = 'renrenfenqi://goodsdetail/goGoodsDetail(' + dataObj.data.description + ')';
            }
        });
        // 打开配置参数
        $("#goods_params").on('click', function () {
            if (client == 'android') {
                renrenAct.goGoodsConfiguration(dataObj.data.configure);
            } else {
                window.location = 'renrenfenqi://goodsdetail/goGoodsConfiguration(' + dataObj.data.configure + ')';
            }
        });
        // 打开评价晒单
        $(".assess").on('click', function () {
            if (client == 'android') {
                renrenAct.goGoodsComments(dataObj.data.goods_map_name);
            } else {
                window.location = 'renrenfenqi://goodsdetail/goGoodsComments(' + dataObj.data.goods_map_name + ')';
            }
        });
        // 用户点击关闭兼职帮助窗口
        $('.title').on('touchstart', function () {
            _utilities.hideMask(0);
            $('.parttime').hide();
        });
        // 用户点击返回按钮
        $('.back').on('touchstart', function () {
            if (client == 'android') {
                renrenAct.goBack();
            } else {
                window.location = 'renrenfenqi://goodsdetail/goBack()';
            }
        });
        // 用户点击立即购买
        $('.goods-buy-btn').on('touchstart', function () {
            console.log(paramsObj);
            console.log(orderObj);
            if (goods) {
                if (client == 'android') {
                    renrenAct.goGoodsVerify(JSON.stringify(paramsObj), JSON.stringify(orderObj));
                } else {
                    window.location = 'renrenfenqi://goodsdetail/goGoodsVerify(' + JSON.stringify(paramsObj) + '--' + JSON.stringify(orderObj) + ')';
                }
            }
        });
    };

    // 设置用户评论
    _setUserAssess = function (data) {
        var assessObj = data;
        $('#assess_num').text(assessObj.data.total);
        var assesslistLength = assessObj.data.list.length;
        for (var i = 0; i < assesslistLength; i++) {
            // 最多显示两条评论
            if (i < 2) {
                var assess_list_top = "<div class='assess-list-top'><span class='userName'>" + assessObj.data.list[i].person + "</span><span class='assess-date'>" + assessObj.data.list[i].time + "</span><span class='start-span' data-sign='span-" + i + "'><img data-sign='0' src='../../img/detail/detail_body_star_n@2x.png' alt=''/><img data-sign='1' src='../../img/detail/detail_body_star_n@2x.png' alt=''/><img data-sign='2' src='../../img/detail/detail_body_star_n@2x.png' alt=''/><img data-sign='3' src='../../img/detail/detail_body_star_n@2x.png' alt=''/><img data-sign='4' src='../../img/detail/detail_body_star_n@2x.png' alt=''/></span></div>";
                var assess_list_bottom = "<ul class='assess-list-bottom'><li class='assess-content'>" + assessObj.data.list[i].content + "</li></ul>";
                var line = "<div class='assess_line' style='width: 90%;margin: 0 auto'></div>";
                $(".assess-list").append(assess_list_top + assess_list_bottom + line);
                var start = Math.round(Number(assessObj.data.list[i].star) / 2);
                for (var j = 0; j < start; j++) {
                    $(".start-span[data-sign='span-" + i + "'] img[data-sign=" + j + "]").attr("src", "../../img/detail/detail_body_star_h@2x.png");
                }
            } else {
                break;
            }
        }
    };

    // 获取客户端类型
    _getClient = function (data) {
        client = data;
    };

    // 异常错误处理
    _utilities.getError = function (e) {
        if (client == 'android') {
            console.log('show error by android!');
            renrenAct.goErr();
        } else if (client == 'ios') {
            console.log('show error by ios!');
            window.location = 'renrenfenqi://goGoodsVerify/goErr()';
        } else {
            alert('数据异常，请稍后再试~');
        }
    };

    // 全局捕获出现的错误
    window.onerror = function (e) {
        _utilities.getError(e);
    };

    return {
        utilities: _utilities,
        getParams: _getParams,
        setUserAssess: _setUserAssess,
        getClient: _getClient
    }
})();